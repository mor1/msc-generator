/*
    This file is part of Msc-generator.
	Copyright 2008,2009,2010 Zoltan Turanyi
	Distributed under GNU Affero General Public License.

    Msc-generator is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Msc-generator is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with Foobar.  If not, see <http://www.gnu.org/licenses/>.
*/
// MscGen2Doc.cpp : implementation of the CMscGen2Doc class
//

#include "stdafx.h"
#include "MscGen2.h"
#include "MainFrm.h"
#include "MscGen2Doc.h"
#include "MscGen2View.h"
#include "SrvrItem.h"
#include ".\mscgen2doc.h"
#include "process.h"
#include <string>
#include <list>
#ifdef _DEBUG
#define new DEBUG_NEW
#endif

CChartData::CChartData(const CChartData& other)
{
	m_buff = NULL;
	m_length = 0;
	m_bModified = FALSE;
	if (!other.IsEmpty()) 
		operator =(other);
}

CChartData & CChartData::operator = (const CChartData& other)
{
	Delete();
	if (other.IsEmpty()) 
		return *this;
	m_buff = (char*)malloc(other.m_length);
	if (m_buff==NULL) 
		return *this;
	m_length = other.m_length;
	memcpy(m_buff, other.m_buff, m_length);
	m_bModified = other.m_bModified;
	return *this;
}


BOOL CChartData::Save(const CString &fileName) 
{
	TRY {
		CStdioFile outfile(fileName, CFile::modeCreate | CFile::modeWrite | CFile::typeText);
		TRY {
			CSingleLock lock(&m_CriticalSection);
			lock.Lock();
			outfile.Write(m_buff, m_length);
		} CATCH(CFileException, pEx) {
			pEx->ReportError();
			outfile.Close();
			return FALSE;
		}
		END_CATCH
		outfile.Close();
	} CATCH(CFileException, pEx) {
		pEx->ReportError();
		return FALSE;
	}
	END_CATCH
	return TRUE;
}



BOOL CChartData::Load(const CString &fileName, BOOL reportError)
{
	unsigned length = 0;
	char *buff = NULL;
	if (fileName.GetLength()>0) {
		CStdioFile infile;
		CFileException Ex;
		if (!infile.Open(fileName, CFile::modeRead | CFile::typeText, &Ex)) {
			if (reportError) Ex.ReportError();
			return FALSE;
		}
		length = infile.GetLength();
		if (length>0) {
			buff = (char*)malloc(length);
			TRY {
				length = infile.Read(buff, length);
			} CATCH(CFileException, pEx) {
				infile.Close();
				free(buff);
				if (reportError) pEx->ReportError();
				return FALSE;
			}
			END_CATCH
		}
		infile.Close();
	}
	CSingleLock lock(&m_CriticalSection);
	lock.Lock();
	Delete();
	m_buff = buff;
	m_length = length;
	lock.Unlock();
	return TRUE;
}

void *CChartData::CreateMsc(bool pedantic, const char *filename, const char *preamble, const char *postscript, const char*design) 
{
	void *msc=NULL;
	if (preamble && strlen(preamble)) {
		msc = Msc_ParseText(preamble, strlen(preamble), "[designlib]", msc, pedantic);
		if (design && strlen(design))
			Msc_ForceDesign(msc, design);
	}
	CSingleLock lock(&m_CriticalSection);
	lock.Lock();
	msc = Msc_ParseText(m_buff, m_length, filename, msc, pedantic);
	lock.Unlock();
	if (postscript && strlen(postscript)) {
		msc = Msc_ParseText(postscript, strlen(postscript), "[copyright]", msc, pedantic);
		Msc_PostParse(msc, 0);
	} else {
		Msc_PostParse(msc, -1);  //Default chartTailGap
	}
	return msc;
}

// COptionDlg dialog

IMPLEMENT_DYNCREATE(COptionDlg, CDialog)

COptionDlg::COptionDlg(CWnd* pParent /*=NULL*/)
	: CDialog(COptionDlg::IDD, pParent)
	, m_Pedantic(FALSE)
	, m_Warnings(FALSE)
	, m_TextEditor(_T(""))
	, m_DefaultText(_T(""))
	, m_ViewMethod(_T(""))
{
}

COptionDlg::~COptionDlg()
{
}

void COptionDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Check(pDX, IDC_CHECK_PEDANTIC, m_Pedantic);
	DDX_Check(pDX, IDC_CHECK_WARNINGS, m_Warnings);
	DDX_CBString(pDX, IDC_COMBO_EDITOR, m_TextEditor);
	DDX_Text(pDX, IDC_EDIT_DEFAULT_TEXT, m_DefaultText);
}

BOOL COptionDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	return TRUE;  // return TRUE  unless you set the focus to a control
}

BEGIN_MESSAGE_MAP(COptionDlg, CDialog)
END_MESSAGE_MAP()


// COptionDlg message handlers


// CMscGen2Doc

IMPLEMENT_DYNCREATE(CMscGen2Doc, COleServerDoc)

BEGIN_MESSAGE_MAP(CMscGen2Doc, COleServerDoc)
	ON_COMMAND(ID_EDIT_UNDO, OnEditUndo)
	ON_COMMAND(ID_EDIT_COPY, OnEditCopy)
	ON_COMMAND(ID_EDIT_PASTE, OnEditPaste)
	ON_COMMAND(ID_FILE_EXPORT, OnFileExport)
	ON_COMMAND(ID_EDIT_PREFERENCES, OnEditPreferences)
	ON_UPDATE_COMMAND_UI(ID_FILE_SAVE, OnUpdateFileExport)
	ON_UPDATE_COMMAND_UI(ID_FILE_SAVE_AS, OnUpdateFileExport)
	ON_UPDATE_COMMAND_UI(ID_FILE_EXPORT, OnUpdateFileExport)
	ON_UPDATE_COMMAND_UI(ID_EDIT_UNDO, OnUpdateEditUndo)
	ON_UPDATE_COMMAND_UI(ID_EDIT_COPY, OnUpdateFileExport)
	ON_UPDATE_COMMAND_UI(ID_EDIT_PASTE, OnUpdateEditPaste)
END_MESSAGE_MAP()

CLIPFORMAT NEAR CMscGen2Doc::m_cfPrivate = NULL;

// CMscGen2Doc construction/destruction

CMscGen2Doc::CMscGen2Doc()
{
	// Use OLE compound files
	EnableCompoundFile();

	// one-time construction code here
	if (m_cfPrivate == NULL)
	{
		m_cfPrivate = (CLIPFORMAT)
		::RegisterClipboardFormat(_T("Msc-Generator Signalling Chart"));
	}
	if (!m_ErrorWindow.Create(IDD_DIALOG1, NULL)) {
		MessageBox(0,"Fail to create error window", "Msc-generator", MB_OK);
	}
	if (!m_ProgressWindow.Create(IDD_PROGRESSDIALOG, NULL)) {
		MessageBox(0,"Fail to create progress window", "Msc-generator", MB_OK);
	}
	m_progress_reference = 0;

	//Options stored in registry
	ReadRegistryValues(false);
	m_page = 0; //all

	m_undo_ModifiedFlag = FALSE;

	m_EditorProcessId = 0;
	m_bModified = FALSE;
	m_hWndForEditor = NULL;
}

CMscGen2Doc::~CMscGen2Doc()
{
}


// CMscGen2Doc server implementation

COleServerItem* CMscGen2Doc::OnGetEmbeddedItem()
{
	// OnGetEmbeddedItem is called by the framework to get the COleServerItem
	//  that is associated with the document.  It is only called when necessary.

	CMscGen2SrvrItem* pItem = new CMscGen2SrvrItem(this);
	ASSERT_VALID(pItem);
	return pItem;
}

// CMscGen2Doc serialization

void CMscGen2Doc::Serialize(CArchive& ar)
{
	CSingleLock lock(&m_data.m_CriticalSection);
	lock.Lock();
	if (ar.IsStoring()) {
		ar << m_ForcedDesign;
		ar << m_page;
		ar.Write(m_data.m_buff, m_data.m_length);
	} else {
		ar >> m_ForcedDesign;
		ar >> m_page;
		m_data.Delete();
		unsigned alloc = 16384;
		m_data.m_buff = (char*)malloc(alloc);
		while (1) {
			m_data.m_length += ar.Read(m_data.m_buff+m_data.m_length, alloc-m_data.m_length);
			if (m_data.m_length == alloc)
				m_data.m_buff = (char*)realloc(m_data.m_buff, alloc+=16384);
			else break;
		}
	}
	lock.Unlock();
}

// CMscGen2Doc diagnostics

#ifdef _DEBUG
void CMscGen2Doc::AssertValid() const
{
	COleServerDoc::AssertValid();
}

void CMscGen2Doc::Dump(CDumpContext& dc) const
{
	COleServerDoc::Dump(dc);
}
#endif //_DEBUG


// CMscGen2Doc commands


void CMscGen2Doc::DeleteContents()
{
	CSingleLock lock(&m_data.m_CriticalSection);
	lock.Lock();
	m_data.Delete();
	lock.Unlock();
	COleServerDoc::DeleteContents();
}

BOOL CMscGen2Doc::OnNewDocument()
{
	StopEditor(STOPEDITOR_WAIT);
	if (!COleServerDoc::OnNewDocument())
		return FALSE;

	// (SDI documents will reuse this document)
	CSingleLock lock(&m_data.m_CriticalSection);
	CSingleLock undo_lock(&m_undo_data.m_CriticalSection);
	lock.Lock();
	undo_lock.Lock();
	m_undo_data = m_data;
	undo_lock.Unlock();
	m_data.Delete();
	m_data.m_length = m_DefaultText.GetLength();
	m_data.m_buff = strdup(m_DefaultText);
	lock.Unlock();
	m_undo_ModifiedFlag = IsModified();
	SetModifiedFlag(FALSE); //unmodified yet
	CMscGen2App *pApp = (CMscGen2App *)::AfxGetApp();
	pApp->FillComboWithDesigns(m_ChartSourcePreamble);
	return TRUE;
}

BOOL CMscGen2Doc::OnOpenDocument(LPCTSTR lpszPathName)
{
	StopEditor(STOPEDITOR_WAIT);
	ASSERT_VALID(this);
	ASSERT(lpszPathName == NULL || AfxIsValidString(lpszPathName));

	CMscGen2App *pApp = (CMscGen2App *)::AfxGetApp();
	ASSERT(pApp != NULL);
	pApp->FillComboWithDesigns(m_ChartSourcePreamble);

	if (lpszPathName == NULL)
		return COleServerDoc::OnOpenDocument(lpszPathName);

	// always register the document before opening it
	Revoke();
	if (!RegisterIfServerAttached(lpszPathName, FALSE))
	{
		// always output a trace (it is just an FYI -- not generally fatal)
		TRACE(traceOle, 0, _T("Warning: Unable to register moniker '%s' as running\n"), lpszPathName);
	}

	USES_CONVERSION;

	if (IsModified())
		TRACE(traceOle, 0, "Warning: OnOpenDocument replaces an unsaved document.\n");

	if (!m_data.Load(lpszPathName)) {
		CFileException e;
		ReportSaveLoadException(lpszPathName, &e,
			FALSE, AFX_IDP_FAILED_TO_OPEN_DOC);
		return FALSE;
	}

	m_undo_data.Delete();

	// if the app was started only to print, don't set user control
	//Copied from COleLinkingDoc
	if (pApp->m_pCmdInfo == NULL ||
		(pApp->m_pCmdInfo->m_nShellCommand != CCommandLineInfo::FileDDE &&
		 pApp->m_pCmdInfo->m_nShellCommand != CCommandLineInfo::FilePrint))
	{
		AfxOleSetUserCtrl(TRUE);
	}
	SetModifiedFlag(FALSE);     // back to unmodified}
	return TRUE;
}

BOOL CMscGen2Doc::OnSaveDocument(LPCTSTR lpszPathName)
{
	if (lpszPathName==NULL) 
		return COleServerDoc::OnSaveDocument(lpszPathName);

	if (!m_data.Save(lpszPathName)) {
		CFileException e;
		ReportSaveLoadException(lpszPathName, &e,
			TRUE, AFX_IDP_FAILED_TO_SAVE_DOC);
		return FALSE;
	}
	//If name changed and an editor is running, restart it (new name)
	if (lpszPathName != GetPathName() && m_EditorFileName.GetLength()>0) {
		std::string name(lpszPathName);
		size_t pos = name.find_last_of("\\/");
		if (pos != std::string::npos)
			name = name.substr(pos+1);
		//CMscGen2View::OnTimer cannot hit between the two, so it remains scheduled
		StopEditor(STOPEDITOR_WAIT);
		StartEditor(name.c_str());
	}

	SetModifiedFlag(FALSE);     // back to unmodified}
	return TRUE;
}

void CMscGen2Doc::OnCloseDocument()
{
	StopEditor(STOPEDITOR_FORCE);
	COleServerDoc::OnCloseDocument();
}

void CMscGen2Doc::OnUpdateFileExport(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(!m_data.IsEmpty());
}


void CMscGen2Doc::OnFileExport()
{
	if (m_data.IsEmpty()) 
		return;
	void *msc = m_data.CreateMsc(m_Pedantic, "", m_ChartSourcePreamble, m_ChartSourcePostscript, m_ForcedDesign);
	CFileDialog m_a(false);
	m_a.m_pOFN->lpstrTitle = "Export to file";
	m_a.m_pOFN->lpstrFilter =	
		"Portable Network Graphics (*.png)\0*.png\0"
		"Windows Bitmap (*.bmp)\0*.bmp\0"
		"Enhanced Metafile (*emf)\0*.emf\0"
		"Scalable Vector Graphics (*svg)\0*.svg\0"
		"Portable Document Format (*.pdf)\0*.pdf\0"
		"Encapsulated PostScript (*.eps)\0*.eps\0";
	m_a.m_pOFN->nFilterIndex = 1;
	char filename[1024] = "*.png";
	m_a.m_pOFN->lpstrFile = filename;
	m_a.m_pOFN->nMaxFile = sizeof(filename);
	if (m_a.DoModal() != IDOK)
		return;
	Msc_Draw_to_File(msc, m_a.GetPathName());
	Msc_Destroy(msc);
}

void CMscGen2Doc::OnUpdateEditUndo(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(!m_undo_data.IsEmpty());
}

void CMscGen2Doc::OnEditUndo()
{
	CSingleLock lock(&m_data.m_CriticalSection);
	CSingleLock undo_lock(&m_undo_data.m_CriticalSection);
	undo_lock.Lock();
	if (m_EditorProcessId) {
		CChartData data = m_undo_data;
		StopEditor(STOPEDITOR_WAIT);
		lock.Lock();
		m_undo_data = m_data;
		m_data = data;
		lock.Unlock();
		StartEditor();
	} else {
		lock.Lock();
		std::swap(m_undo_data, m_data);
		lock.Unlock();
	}
	bool Modified = IsModified();
    SetModifiedFlag(m_undo_ModifiedFlag);
	m_undo_ModifiedFlag = Modified;
	NotifyChanged();  //for OLE
	UpdateAllViews(NULL);
}

void CMscGen2Doc::OnEditCopy()
{
	//Copy is handled by SrvItem
	CMscGen2SrvrItem *pItem= GetEmbeddedItem();
	pItem->CopyToClipboard();
}

void CMscGen2Doc::OnSetItemRects(LPCRECT lpPosRect , LPCRECT lpClipRect)
{
	// call base class to change the size of the window
	COleServerDoc::OnSetItemRects(lpPosRect, lpClipRect);

	// notify first view that scroll info should change
//	POSITION pos = GetFirstViewPosition();
//	CMscGen2View* pView = (CMscGen2View*)GetNextView(pos);
//	pView->ResyncScrollSizes();
}

void CMscGen2Doc::OnUpdateEditPaste(CCmdUI *pCmdUI)
{
	COleDataObject dataObject;
	dataObject.AttachClipboard();
	pCmdUI->Enable(dataObject.IsDataAvailable(m_cfPrivate) || 
                   dataObject.IsDataAvailable(CF_TEXT));
}

void CMscGen2Doc::OnEditPaste()
{
	// Paste is handled by Document
	COleDataObject dataObject;
	dataObject.AttachClipboard();
	if (dataObject.IsDataAvailable(m_cfPrivate)) {
		// get file refering to clipboard data
		CFile *pFile = dataObject.GetFileData(m_cfPrivate);
		if (pFile == NULL) return;
		// connect the file to the archive and read the contents
		CArchive ar(pFile, CArchive::load);
		ar.m_pDocument = this; // for COleClientItem serialize
		CSingleLock undo_lock(&m_undo_data.m_CriticalSection);
		undo_lock.Lock();
		m_undo_data = m_data;
		undo_lock.Unlock();
		Serialize(ar);
		ar.Close();
		delete pFile;
		if (m_EditorProcessId) {
			StopEditor(STOPEDITOR_FORCE);
			StartEditor("Untitled.signalling");
		}
		m_undo_ModifiedFlag = IsModified();
		SetModifiedFlag();
		NotifyChanged();  //for OLE
		UpdateAllViews(NULL);
	} else if (dataObject.IsDataAvailable(CF_TEXT)) {
		HGLOBAL hGlobal = dataObject.GetGlobalData(CF_TEXT);
		unsigned length = GlobalSize(hGlobal);
		void* v = GlobalLock(hGlobal);
		if (v!=NULL && length>0) {
			CSingleLock lock(&m_data.m_CriticalSection);
			CSingleLock undo_lock(&m_undo_data.m_CriticalSection);
			lock.Lock();
			undo_lock.Lock();
			m_undo_data = m_data;
			undo_lock.Unlock();
			m_data.Delete();
			m_data.m_length = length;
			m_data.m_buff = (char*)malloc(length);
			memcpy(m_data.m_buff, v, m_data.m_length);
			lock.Unlock();
			if (m_EditorProcessId) {
				StopEditor(STOPEDITOR_FORCE);
				StartEditor("Untitled.signalling");
			}
			m_undo_ModifiedFlag = IsModified();
			SetModifiedFlag();
			NotifyChanged();  //for OLE
			UpdateAllViews(NULL);
		}
		GlobalUnlock(hGlobal);
		GlobalFree(hGlobal);
	}
}

void CMscGen2Doc::OnEditPreferences()
{
	CMscGen2App *pApp = (CMscGen2App *)::AfxGetApp();
	COptionDlg optionDlg;
	optionDlg.m_Pedantic = m_Pedantic;
	optionDlg.m_Warnings = m_Warnings;
	optionDlg.m_TextEditor = m_sTextEditor;
	optionDlg.m_DefaultText = m_DefaultText;
	optionDlg.m_DefaultText.Replace("\x0d", "\x0d\x0a");
	if (optionDlg.DoModal() == IDOK) {
		if (m_Pedantic != optionDlg.m_Pedantic || m_Warnings != optionDlg.m_Warnings) {
			m_Pedantic = optionDlg.m_Pedantic;
			m_Warnings = optionDlg.m_Warnings;
			pApp->WriteProfileInt(REG_SECTION_SETTINGS, REG_KEY_PEDANTIC, m_Pedantic);
			pApp->WriteProfileInt(REG_SECTION_SETTINGS, REG_KEY_WARNINGS, m_Warnings);
			UpdateAllViews(NULL);  //To recompile & add/remove warnings
		}
		if (optionDlg.m_TextEditor.GetLength() &&  m_sTextEditor != optionDlg.m_TextEditor) {
			pApp->WriteProfileString(REG_SECTION_SETTINGS, REG_KEY_TEXTEDITOR, optionDlg.m_TextEditor);
			m_sTextEditor = optionDlg.m_TextEditor;
			if (m_EditorProcessId) {
				//CMscGen2View::OnTimer cannot hit between the two, so it remains scheduled
				StopEditor(STOPEDITOR_WAIT);
				StartEditor();
			}
		}
		if (optionDlg.m_DefaultText != m_DefaultText) {
			m_DefaultText = optionDlg.m_DefaultText;
			int rep = m_DefaultText.Replace("\x0a", "");
			pApp->WriteProfileString(REG_SECTION_SETTINGS, REG_KEY_DEFAULTTEXT, m_DefaultText);
		}
	}
}

void CMscGen2Doc::ReadRegistryValues(bool reportProblem) 
{
	CMscGen2App *pApp = (CMscGen2App *)::AfxGetApp();
	//Load Registry values
	m_Pedantic = pApp->GetProfileInt(REG_SECTION_SETTINGS, REG_KEY_PEDANTIC, FALSE);
	m_Warnings = pApp->GetProfileInt(REG_SECTION_SETTINGS, REG_KEY_WARNINGS, TRUE);
	m_sTextEditor = pApp->GetProfileString(REG_SECTION_SETTINGS, REG_KEY_TEXTEDITOR, "C:\\Windows\\Notepad.exe");
	m_DefaultText= pApp->GetProfileString(REG_SECTION_SETTINGS, REG_KEY_DEFAULTTEXT, 
		"#Default signalling chart\na,b,c;\nb->c:trallala;\na->b: new;\n");
	m_DefaultText.Replace("\x0a", "");

	//Non-registry settings
	m_TextPaths = FALSE;
	m_ViewMethod = DRAW_EMF;

	char buff[1024]; 
	GetModuleFileName(NULL, buff, 1024);
	std::string dir(buff);
	int pos = dir.find_last_of('\\');
	ASSERT(pos!=std::string::npos);
	CString designlib_filename = dir.substr(0,pos).append("\\designlib.signalling").c_str();

	ReadDesigns(designlib_filename, reportProblem); //fills m_ChartSourcePreamble appropriately
	m_ChartSourcePostscript = "nudge; nudge; [text.ident=right, text.format=\"\\md(0)\\mu(2)\\mr(0)\\mn(10)\\f(arial)\","
		                      "text.color=gray, number=no, compress=no, vline.type=none, _wide=yes]"
							  ": http://msc-generator.sourceforge.net";
	m_ChartSourcePostscript.AppendFormat(" v%d.%d.%d;", LIBMSCGEN_MAJOR, LIBMSCGEN_MINOR, LIBMSCGEN_SUPERMINOR);
}

//Read the designs from m_DesignDir, display a modal dialog if there is a problem.
//If no problem, update m_ChartSourcePreamble and return true
bool CMscGen2Doc::ReadDesigns(const char *fileName, bool reportProblem)
{
	CString preamble;
	CString msg;
	CFileFind finder;
	bool errors = true;
	if (finder.FindFile(fileName)) {
		finder.FindNextFile();
		CChartData data;
		if (data.Load(finder.GetFilePath(), false)) {
			void* msc = data.CreateMsc(true, "[designlib]");
			char buff[1024]; 
			errors = Msc_GetErrors(msc, true, buff, sizeof(buff));
			if (strlen(buff)) {
				if (errors) 
					msg.Append("Errors in design file: ");
				else 
					msg.Append("Warnings in design file: ");
				msg.Append(finder.GetFileName());
				msg.Append("\n");
				msg.Append(buff);
				if (errors) 
					msg.Append("No design files loaded.");
				if (reportProblem)
					MessageBox(NULL, msg, "Msc-generator", MB_OK);
			}
			char *heyho = (char*)malloc(data.m_length+1);
			memcpy(heyho, data.m_buff, data.m_length);
			heyho[data.m_length] = 0;
			preamble.Append(heyho);
			free(heyho);
		}
	}
	if (msg.GetLength()>0 && reportProblem)
		MessageBox(NULL, msg, "Msc-generator", MB_OK);
	if (preamble.GetLength()>0) 
		m_ChartSourcePreamble = preamble;
	else 
		m_ChartSourcePreamble = ";\n";
	return !errors;
}


void CMscGen2Doc::CopyErrorsToWindow(char *text) 
{
	CEdit *pEdit = (CEdit*)m_ErrorWindow.GetDlgItem(IDC_EDIT1);
	CString errors(text);
	int pos = 0;
	do {
		pos = errors.Find('\n', pos);
		if (pos>=0) {
			errors.Insert(pos, '\r');
			pos+=2;
		}
	} while (pos>=0);
	pEdit->SetWindowText(errors);
	if (strlen(text))
		m_ErrorWindow.ShowWindow(SW_SHOW); //Activate
	else
		m_ErrorWindow.ShowWindow(SW_HIDE); //Activate
}


void CMscGen2Doc::StartEditor(CString filename)
{
	if (m_EditorProcessId) return;

	//Set global variables for CModifierThread
	if (filename.GetLength() > 0 || m_EditorFileName.GetLength() == 0) {
		if (filename.GetLength() == 0)
			filename = "Untitled.signalling";
		if (filename.Right(11)==".signalling")
			m_EditorFileName.Format("%04d - Text of %s", rand()%1000, filename);
		else
			m_EditorFileName.Format("%04d - Text of %s.signalling", rand()%1000, filename);
		char buff[1024];
		GetTempPath(sizeof(buff), buff);
		m_EditorFileName.Insert(0, buff);
	}

	m_data.Save(m_EditorFileName);
	CFileStatus status;
	CFile::GetStatus(m_EditorFileName, status);
	m_EditorFileLastMod = status.m_mtime;

	CString cmdLine = m_sTextEditor + " \"" + CString(m_EditorFileName) + "\"";
	char* cmdline = strdup(cmdLine);
	STARTUPINFO si;
	si.cb = sizeof(STARTUPINFO);
	si.lpDesktop = NULL;
	si.lpTitle = strdup(m_EditorFileName.GetString());
	si.dwFlags = 0;
	si.lpReserved = NULL;
	si.lpReserved2 = NULL;
	si.cbReserved2 = NULL;
	PROCESS_INFORMATION pi;
	if (!CreateProcess(NULL, cmdline, NULL, NULL, FALSE, 0, NULL, NULL,  &si, &pi)) {
		free(cmdline);
		free(si.lpTitle);
		StopEditor(STOPEDITOR_FORCE); //Delete temp file and null the filename
		return;
	}
	m_EditorProcessId = pi.dwProcessId;
	CloseHandle(pi.hProcess);
	CloseHandle(pi.hThread);
	free(cmdline);
	free(si.lpTitle);
};

bool CMscGen2Doc::CheckIfEditorFileHasBeenUpdated()
{
	if (m_EditorFileName.GetLength()>0) {
		CFileStatus status;
		//Query file status
		if (CFile::GetStatus(m_EditorFileName, status)) {
			//Check if the file has been updated by the editor
			if (m_EditorFileLastMod != status.m_mtime) {
				//Load modification
				CChartData data;
				if (data.Load(m_EditorFileName, FALSE)) {
					//OK: File successfully read, update the CDocument.
					CSingleLock lock(&m_data.m_CriticalSection);
					CSingleLock undo_lock(&m_undo_data.m_CriticalSection);
					lock.Lock();
					undo_lock.Lock();
					m_undo_data = m_data;
                    undo_lock.Unlock();
					m_data = data;
					m_data.m_bModified = FALSE;
					lock.Unlock();
					m_EditorFileLastMod = status.m_mtime;
					m_undo_ModifiedFlag = IsModified();
					SetModifiedFlag();
					//Now update the View
					NotifyChanged();  //for OLE
					UpdateAllViews(NULL);
					return true;
				}
			}
		}
	}
	return false;
}


struct window_search {
	DWORD processId;
	std::list<HWND> hWnd_result;
};

BOOL CALLBACK EnumWindowsProcFindTopWindowByProcess(HWND hwnd, LPARAM lParam)
{
	DWORD processId;
	GetWindowThreadProcessId(hwnd, &processId);
	if (processId == reinterpret_cast<struct window_search*>(lParam)->processId)
		reinterpret_cast<window_search*>(lParam)->hWnd_result.push_back(hwnd);
	return true; //continue iteration
}



void CMscGen2Doc::StopEditor(EStopEditor force)
{
	if (m_EditorProcessId) {
		switch (force) {
		case STOPEDITOR_FORCE:
			{
			HANDLE h = OpenProcess(PROCESS_ALL_ACCESS, FALSE, m_EditorProcessId);
			TerminateProcess(h, 0);
			CloseHandle(h);
			m_EditorProcessId = 0;
			//continue with removing editor file
			break;
			}
		case STOPEDITOR_NOWAIT:
		case STOPEDITOR_WAIT:
			struct window_search search;
			search.processId = m_EditorProcessId;
			EnumWindows(EnumWindowsProcFindTopWindowByProcess, (LPARAM)&search);
			int ii = search.hWnd_result.size();
			for (std::list<HWND>::iterator i=search.hWnd_result.begin(); i!=search.hWnd_result.end(); i++) {
				char buff[1024];
				int len = GetWindowText(*i, buff, sizeof(buff)); 
				if (strstr(buff, "signalling")!=NULL) {
					SetForegroundWindow(*i);
					SendMessage(*i, WM_CLOSE, 0, 0); 
				}
			}
			if (force == STOPEDITOR_NOWAIT)
				//Okay let us wait till the editor actually closes
				//CView::OnTimer will detect the loss of the editor process and then
				//1) set m_EditorProcessId to zero; 2) call us (StopEditor) so we remove the editor file
				return;
			//If we are forced to close, wait till editor process closes
			bool wait = true;
			while (wait) { 
				HANDLE h = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, m_EditorProcessId);
				wait = GetPriorityClass(h);  //this checks if process still there
				CloseHandle(h);
				Sleep(300);
			}
			CheckIfEditorFileHasBeenUpdated(); //update the document if editor has made last minute edits
		}
	}
	if (m_EditorFileName.GetLength()>0) {
		TRY {
			CFile::Remove(m_EditorFileName);
		} CATCH(CFileException, pEx) {
		}
		END_CATCH
		m_EditorFileName.Empty();
	}
}

void CMscGen2Doc::SetPagesInComboBox(unsigned pages)
{
	CMscGen2App *pApp = (CMscGen2App *)::AfxGetApp();
	if (pApp != NULL && pApp->m_pDesignBar != NULL) {
		CComboBox *combo = (CComboBox*)pApp->m_pDesignBar->GetDlgItem(IDC_COMBO_PAGE);
		if (combo!=NULL) {
			if (pages+1 != combo->GetCount() && (pages != 1 || combo->GetCount() != 1)) {
				combo->ResetContent();
				//Fill combo list with the appropriate number of pages
				combo->AddString("(all)");
				CString str;
				if (pages > 1)
					for (int i=1; i<=pages; i++) {
						str.Format("%d", i);
						combo->AddString(str);
					}
				else
					m_page=0;
			}
			if (m_page > pages)
				m_page = pages;
			//Set the index to the current page
			combo->SetCurSel(m_page);
		}
	} 
}

void CMscGen2Doc::DestroyInPlaceFrame(COleIPFrameWnd* pFrameWnd)
{
	// Stop editor
	StopEditor(STOPEDITOR_FORCE);
	COleServerDoc::DestroyInPlaceFrame(pFrameWnd);
}

COleIPFrameWnd* CMscGen2Doc::CreateInPlaceFrame(CWnd* pParentWnd)
{
	// Start Editor
	POSITION pos = GetFirstViewPosition();
	CMscGen2View* pView = (CMscGen2View*)GetNextView(pos);
	pView->OnButtonEdittext();
	return COleServerDoc::CreateInPlaceFrame(pParentWnd);
}

void CMscGen2Doc::OnShowControlBars(CFrameWnd* pFrameWnd, BOOL bShow)
{
	if (bShow) {
		//Fill the combo boxes of design bars
		CMscGen2App *pApp = (CMscGen2App *)::AfxGetApp();
		pApp->FillComboWithDesigns(m_ChartSourcePreamble);
		POSITION pos = GetFirstViewPosition();
		CMscGen2View* pView = (CMscGen2View*)GetNextView(pos);
		SetPagesInComboBox(pView->m_pages);
		pApp->m_pDesignBar->Invalidate();
	}

	COleServerDoc::OnShowControlBars(pFrameWnd, bShow);
}


void CMscGen2Doc::StartDrawingProgress() 
{
	m_progress_reference++;
	if (m_progress_reference>0) 
		m_ProgressWindow.ShowWindow(SW_SHOW); //Activate
	else
		m_ProgressWindow.ShowWindow(SW_HIDE); 
}

void CMscGen2Doc::StopDrawingProgress()
{
	m_progress_reference--;
	if (m_progress_reference<0) {
		MessageBox(0,"Progress reference is negative", "Msc-generator error", MB_OK);
		m_progress_reference=0;
	}
	if (m_progress_reference>0) 
		m_ProgressWindow.ShowWindow(SW_SHOW); //Activate
	else
		m_ProgressWindow.ShowWindow(SW_HIDE); 
}
