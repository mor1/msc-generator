//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MscGen2.rc
//
#define IDR_SRVR_INPLACE                4
#define IDR_SRVR_EMBEDDED               5
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_HTML_OPTIONDLG              103
#define IDR_MAINFRAME                   128
#define IDR_MscGen2TYPE                 129
#define IDD_DIALOG1                     131
#define IDD_DIALOG_OPTIONS              132
#define IDD_DESIGNBAR                   134
#define IDD_PROGRESSDIALOG              135
#define IDC_EDIT1                       1001
#define IDC_COMBO_EDITOR                1002
#define IDC_CHECK_PEDANTIC              1003
#define IDC_CHECK_WARNINGS              1004
#define IDC_EDIT_DEFAULT_TEXT           1007
#define IDC_BUTTON_DESIGN_LEFT          1008
#define IDC_COMBO_DESIGN                1009
#define IDC_BUTTON_DESIGN_RIGHT         1010
#define IDC_COMBO_VIEWMODE              1010
#define IDC_CHECK_TEXTPATHS             1011
#define IDC_BUTTON_PAGE_MINUS           1011
#define IDC_COMBO_DESIGN2               1012
#define IDC_COMBO_PAGE                  1012
#define IDC_BUTTON_PAGE_PLUS            1013
#define IDC_COMBO_ZOOM                  1014
#define IDC_COMBO1                      1014
#define ID_CANCEL_EDIT_SRVR             32769
#define ID_FILE_EXPORTTOPNG             32772
#define ID_FILE_EXPORTTOSVG             32773
#define ID_FILE_EXPORTTOEPS             32774
#define ID_FILE_EXPORTTOPDF             32775
#define ID_FILE_IMPORTFROMTEXT          32776
#define ID_FILE_EXPORTTOTEXT            32777
#define ID_NOTIFICATION_DATA_CHANGED    32778
#define ID_BUTTON_EDITTEXT              32779
#define ID_FILE_EXPORT                  32784
#define ID_EDIT_OPTIONS                 32785
#define ID_EDIT_PREFERENCES             32786
#define ID_VIEW_DESIGNBAR               32790
#define ID_VIEW_ZOOMIN                  32792
#define ID_VIEW_ZOOMOUT                 32793
#define ID_VIEW_ZOOMNORMALIZE           32794
#define ID_VIEW_REDRAW                  32805
#define ID_VIEW_ZOOMMODE                32812
#define ID_ZOOMMODE_KEEPINOVERVIEW      32813
#define ID_ZOOMMODE_KEEPADJUSTINGWINDOWWIDTH 32814
#define ID_ZOOMMODE_KEEPFITTINGTOWIDTH  32815
#define ID_VIEW_ADJUSTWIDTH             32816
#define ID_VIEW_FITTOWIDTH              32817

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32822
#define _APS_NEXT_CONTROL_VALUE         1015
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
