/*
    This file is part of Msc-generator.
	Copyright 2008,2009,2010 Zoltan Turanyi
	Distributed under GNU Affero General Public License.

    Msc-generator is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Msc-generator is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with Foobar.  If not, see <http://www.gnu.org/licenses/>.
*/
// MscGen2.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "MscGen2.h"
#include "MainFrm.h"

#include "IpFrame.h"
#include "MscGen2Doc.h"
#include "MscGen2View.h"
#include ".\mscgen2.h"
#include <sstream>
#include <vector>
#include <list>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

const char * usage()
{
    return 
"Usage: mscgen [infile]\n"
"       mscgen -T <type> [-o <file>] [<infile>] [-q] \n"
"       mscgen -l\n"
"       mscgen /register\n"
"\n"
"Where:\n"
" -T <type>   Invokes command-line mode and specifies the output file type,\n"
"             which maybe one of 'png', 'eps', 'pdf', 'svg' or 'wmf'.\n"
"             The absence of -T, -l and /registed makes Msc-generator to start\n"
"             as a windowed program.\n"
" -o <file>   Write output to the named file.  If omitted the input filename\n"
"             will be appended by .png or .ps. If neither input nor output \n"
"             file is given, mscgen_out.{png,eps,svg,pdf,wmf} will be used.\n"
" <infile>    The file from which to read input.  If omitted or specified as\n"
"             '-', input will be read from stdin.\n"
" -q          Quiet: Errors and warnings will not display in a dialog.\n"
" -l          Display program licence and exit.\n"
"/register    Run this once as administrator, from the installed location to\n"
"             perform OLE registration.\n"
"\n"
"Msc-generator version 2.1, Copyright (C) 2008-9 Zoltan Turanyi,\n"
"Msc-generator comes with ABSOLUTELY NO WARRANTY.  This is free software, and you are\n"
"welcome to redistribute it under certain conditions; type `mscgen -l' for\n"
"details.\n";
}

/** Print program licence and return.
 */
const char * licence()
{
return 
"Msc-generator, a message sequence chart renderer.\n"
"Copyright (C) 2008-2009 Zoltan Turanyi\n"
"\n"
"This program is free software; you can redistribute it and/or modify\n"
"it under the terms of the GNU General Public License as published by\n"
"the Free Software Foundation; either version 2 of the License, or\n"
"(at your option) any later version.\n"
"\n"
"This program is distributed in the hope that it will be useful,\n"
"but WITHOUT ANY WARRANTY; without even the implied warranty of\n"
"MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n"
"GNU General Public License for more details.\n"
"\n"
"You should have received a copy of the GNU General Public License\n"
"along with this program; if not, write to the Free Software\n"
"Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301, USA\n";
}

CString GetNextArg(CString &cmd) 
{
	while (cmd.GetLength()>0) {
		int pos = cmd.Find(' ');
		if (pos == -1) pos = cmd.GetLength();
		CString arg = cmd.Left(pos);
		cmd.Delete(0,pos+1);
		if (arg.GetLength()>0) return arg;
	}
	return CString();
}

bool CMscGen2App::CommandLineMain(CString cmd)
{
	CString oOutputFile;
	CString oOutType;
	CString oInputFile;
	BOOL messages = TRUE;
	std::ostringstream message;
	CChartData data;

	while (cmd.GetLength()>0) {
		CString arg = GetNextArg(cmd);
		if (arg.GetLength()==0) continue;
		if (!arg.CompareNoCase("-o") || !arg.CompareNoCase("/o")) {
			oOutputFile = GetNextArg(cmd);
			if (oOutputFile.GetLength()==0) {
				message<<"Error: Missing output filename after '-o'."<<std::endl;
				message<<usage();
				goto error;
			}
		} else if (!arg.CompareNoCase("-T") || !arg.CompareNoCase("/T")) {
			arg = GetNextArg(cmd);
			if (arg.GetLength()==0) {
				message<<"Error: Missing output type after '-T'."<<std::endl;
				message<<usage();
				goto error;
			}
			if (!arg.CompareNoCase("png") ||
				!arg.CompareNoCase("eps") ||
				!arg.CompareNoCase("pdf") ||
				!arg.CompareNoCase("svg") ||
				!arg.CompareNoCase("emf")) {
				oOutType = arg;
			} else {
				message<<"Error: Unknown output format '" << arg << "'. Use one of 'png', 'eps', 'pdf', 'svg', 'emf'." <<std::endl;
				goto error;
			}
		} else if (!arg.CompareNoCase("-q") || !arg.CompareNoCase("/q")) {
			messages = FALSE;
		} else if (!arg.CompareNoCase("-l") || !arg.CompareNoCase("/l")) {
			message << licence();
			goto error;
		//All switches processed, now input filename
		} else if (oInputFile.GetLength()==0) {
			oInputFile=arg;
		//We already stored a filename, see if there was a -T
		} else if (oOutType.GetLength()>0) {
			message<<"Error: Unknown option '"<<arg<<"'. (Can only specify one input file?)";
			message << usage();
			goto error;
		//Silently return and continue in windowed mode
		} else 
			return TRUE;
	} /* while */

	//If no -t specified, continue as windowed
	if (oOutType.GetLength()==0)
		return TRUE;

    /* Determine output filename */
    if (oOutputFile == "") {
		std::string tmp = oInputFile;
        size_t dot=tmp.find_last_of('.');
        size_t dash=tmp.find_last_of("/\\");
        //Remove extension, if any and not only an extension
		if (dot!=std::string::npos && dot!=0 &&
			(dash==std::string::npos || dash<dot))
            tmp.erase(dot);
		oOutputFile = tmp.c_str();
		oOutputFile.Append(".");
		oOutputFile.Append(oOutType);
    }
	if (!data.Load(oInputFile)) {
		message<< "Error: Failed to open input file '" << oInputFile << std::endl;
		goto error;
	}
	void *msc = data.CreateMsc(GetProfileInt(REG_SECTION_SETTINGS, REG_KEY_PEDANTIC, FALSE), oInputFile);
	char buff[4096];
	if (!Msc_GetErrors(msc, GetProfileInt(REG_SECTION_SETTINGS, REG_KEY_WARNINGS, TRUE), buff, sizeof(buff))) {
		Msc_Draw_to_File(msc, oOutputFile);
		message << buff;
		message << "Success." << std::endl;
	} else {
		message << buff;
	}
	Msc_Destroy(msc);
error:
	if (messages) {
		CString title("Msc-generator for ");
		title.Append(oInputFile);
		MessageBox(0, message.str().c_str(), title, MB_OK);
	}
	return FALSE;
}

// CMscGen2App

BEGIN_MESSAGE_MAP(CMscGen2App, CWinApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	// Standard file based document commands
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
END_MESSAGE_MAP()


// CMscGen2App construction

CMscGen2App::CMscGen2App()
{
	// Place all significant initialization in InitInstance
	m_pDesignBar = NULL;
}

void CMscGen2App::FillComboWithDesigns(const char *preamble)
{
	if (m_pDesignBar==NULL) return;
	CComboBox *combo = (CComboBox*)m_pDesignBar->GetDlgItem(IDC_COMBO_DESIGN);
	if (combo==NULL) return;

	CChartData tmp;
	void *msc = tmp.CreateMsc(true, "[designlib]", preamble);
	char buff[4096];
	Msc_GetDesigns(msc, buff, sizeof(buff));
	Msc_Destroy(msc);
	CString designs(buff);
	designs.Append(" ");

	combo->ResetContent();
	combo->AddString("(use chart-defined)");
	combo->AddString("plain");
	while (designs.GetLength()) {
		int pos = designs.Find(' ');
		if (designs.Left(pos) != "plain")
			combo->AddString(designs.Left(pos));
		designs.Delete(0, pos+1);
	}
	//restore the selection to the saved style if it can be found
	int index = combo->FindString(-1, m_ForcedDesignToShow);
	if (index < 0)
		combo->SetCurSel(0);
	else 
		combo->SetCurSel(index);
};



// The one and only CMscGen2App object
CMscGen2App theApp;

// This identifier was generated to be statistically unique for your app
// You may change it if you prefer to choose a specific identifier
// {453AC3C8-F260-4D88-832A-EC957E92FDEB}
static const CLSID clsid =
{ 0x453AC3C8, 0xF260, 0x4D88, { 0x83, 0x2A, 0xEC, 0x95, 0x7E, 0x92, 0xFD, 0xEC } };

// CMscGen2App initialization

BOOL CMscGen2App::InitInstance()
{
	srand((unsigned)time(NULL)); 

	// InitCommonControls() is required on Windows XP if an application
	// manifest specifies use of ComCtl32.dll version 6 or later to enable
	// visual styles.  Otherwise, any window creation will fail.
	InitCommonControls();

	CWinApp::InitInstance();

	// Initialize OLE libraries
	if (!AfxOleInit())
	{
		AfxMessageBox(IDP_OLE_INIT_FAILED);
		return FALSE;
	}
	// Standard initialization
	// If you are not using these features and wish to reduce the size
	// of your final executable, you should remove from the following
	// the specific initialization routines you do not need
	// Change the registry key under which our settings are stored
	// such as the name of your company or organization
	SetRegistryKey(_T("Zoltan Turanyi"));
	LoadStdProfileSettings(4);  // Load standard INI file options (including MRU)
	// Register the application's document templates.  Document templates
	//  serve as the connection between documents, frame windows and views
	CSingleDocTemplate* pDocTemplate;
	pDocTemplate = new CSingleDocTemplate(
		IDR_MAINFRAME,
		RUNTIME_CLASS(CMscGen2Doc),
		RUNTIME_CLASS(CMainFrame),       // main SDI frame window
		RUNTIME_CLASS(CMscGen2View));
	if (!pDocTemplate)
		return FALSE;
	pDocTemplate->SetServerInfo(
		IDR_SRVR_EMBEDDED, IDR_SRVR_INPLACE,
		RUNTIME_CLASS(CInPlaceFrame));
	AddDocTemplate(pDocTemplate);
	// Connect the COleTemplateServer to the document template
	//  The COleTemplateServer creates new documents on behalf
	//  of requesting OLE containers by using information
	//  specified in the document template
	m_server.ConnectTemplate(clsid, pDocTemplate, TRUE);
		// Note: SDI applications register server objects only if /Embedding
		//   or /Automation is present on the command line
	// Enable DDE Execute open
	EnableShellOpen();
	RegisterShellFileTypes(TRUE);

	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);
	// App was launched with /Embedding or /Automation switch.
	// Run app as automation server.
	if (cmdInfo.m_bRunEmbedded || cmdInfo.m_bRunAutomated)
	{
		// Register all OLE server factories as running.  This enables the
		//  OLE libraries to create objects from other applications
		COleTemplateServer::RegisterAll();
	
		// Don't show the main window
		return TRUE;
	}
	// App was launched with /Unregserver or /Unregister switch.  Unregister
	// typelibrary.  Other unregistration occurs in ProcessShellCommand().
	if (cmdInfo.m_nShellCommand == CCommandLineInfo::AppUnregister)
	{
		UnregisterShellFileTypes();
		m_server.UpdateRegistry(OAT_INPLACE_SERVER, NULL, NULL, FALSE);
	}
	// App was launched with /Register
	// or /Regserver.  Update registry entries, including typelibrary.
	else if (cmdInfo.m_nShellCommand == CCommandLineInfo::AppRegister)
	{
		m_server.UpdateRegistry(OAT_INPLACE_SERVER);
	}
	// App started with other switches or standalone, see if there is -T to do a command line run
	else if (!CommandLineMain(m_lpCmdLine))
		return FALSE;
	// Dispatch commands specified on the command line.  Will return FALSE if
	// app was launched with /RegServer, /Register, /Unregserver or /Unregister.
	if (!ProcessShellCommand(cmdInfo))
		return FALSE;
	// The one and only window has been initialized, so show and update it
	m_pMainWnd->ShowWindow(SW_SHOW);
	m_pMainWnd->UpdateWindow();
	// call DragAcceptFiles only if there's a suffix
	//  In an SDI app, this should occur after ProcessShellCommand
	// Enable drag/drop open
	m_pMainWnd->DragAcceptFiles();
	return TRUE;
}



// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()

// App command to run the dialog
void CMscGen2App::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}


// CMscGen2App message handlers

