/*
    This file is part of Msc-generator.
	Copyright 2008,2009,2010 Zoltan Turanyi
	Distributed under GNU Affero General Public License.

    Msc-generator is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Msc-generator is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with Foobar.  If not, see <http://www.gnu.org/licenses/>.
*/
// IpFrame.cpp : implementation of the CInPlaceFrame class
//

#include "stdafx.h"
#include "MscGen2.h"

#include "IpFrame.h"
#include ".\ipframe.h"

#include "MscGen2View.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CInPlaceFrame

IMPLEMENT_DYNCREATE(CInPlaceFrame, COleIPFrameWnd)

BEGIN_MESSAGE_MAP(CInPlaceFrame, COleIPFrameWnd)
	ON_WM_CREATE()
	ON_COMMAND(ID_VIEW_DESIGNBAR, OnViewDesignbar)
	ON_UPDATE_COMMAND_UI(ID_VIEW_DESIGNBAR, OnUpdateViewDesignbar)
END_MESSAGE_MAP()


// CInPlaceFrame construction/destruction

CInPlaceFrame::CInPlaceFrame()
{
}

CInPlaceFrame::~CInPlaceFrame()
{
}

int CInPlaceFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (COleIPFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	// CResizeBar implements in-place resizing.
	if (!m_wndResizeBar.Create(this))
	{
		TRACE0("Failed to create resize bar\n");
		return -1;      // fail to create
	}

	// By default, it is a good idea to register a drop-target that does
	//  nothing with your frame window.  This prevents drops from
	//  "falling through" to a container that supports drag-drop.
	m_dropTarget.Register(this);

	return 0;
}

// OnCreateControlBars is called by the framework to create control bars on the
//  container application's windows.  pWndFrame is the top level frame window of
//  the container and is always non-NULL.  pWndDoc is the doc level frame window
//  and will be NULL when the container is an SDI application.  A server
//  application can place MFC control bars on either window.
BOOL CInPlaceFrame::OnCreateControlBars(CFrameWnd* pWndFrame, CFrameWnd* pWndDoc)
{
	// Remove this if you use pWndDoc
	UNREFERENCED_PARAMETER(pWndDoc);

	// Set owner to this window, so messages are delivered to correct app
	m_wndToolBar.SetOwner(this);
	m_DesignBar.SetOwner(this);

	// Create toolbar on client's frame window
	if (!m_wndToolBar.CreateEx(pWndFrame, TBSTYLE_FLAT,WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_SRVR_INPLACE))
	{
		TRACE0("Failed to create toolbar\n");
		return FALSE;
	}

	if (!m_DesignBar.Create(this, IDD_DESIGNBAR, CBRS_TOP, IDD_DESIGNBAR))
	{
		TRACE0("Failed to create design bar\n");
		return -1;      // fail to create
	}
	//These two below Do not run somehow...
	m_DesignBar.m_pDockSite = pWndFrame;
	pWndFrame->AddControlBar(&m_DesignBar);

	//Make bars dockable
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	m_DesignBar.EnableDocking(CBRS_ALIGN_ANY);
	pWndFrame->EnableDocking(CBRS_ALIGN_ANY);
	pWndFrame->DockControlBar(&m_wndToolBar, AFX_IDW_DOCKBAR_TOP);
	pWndFrame->RecalcLayout(TRUE);
	CRect r;
	m_wndToolBar.GetWindowRect(&r);
    r.OffsetRect(1, 0);
	pWndFrame->DockControlBar(&m_DesignBar, AFX_IDW_DOCKBAR_TOP, &r);

	CMscGen2App *pApp = (CMscGen2App *)::AfxGetApp();
	pApp->m_pDesignBar = &m_DesignBar;
	return TRUE;
}

BOOL CInPlaceFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying the CREATESTRUCT cs

	return COleIPFrameWnd::PreCreateWindow(cs);
}


// CInPlaceFrame diagnostics

#ifdef _DEBUG
void CInPlaceFrame::AssertValid() const
{
	COleIPFrameWnd::AssertValid();
}

void CInPlaceFrame::Dump(CDumpContext& dc) const
{
	COleIPFrameWnd::Dump(dc);
}
#endif //_DEBUG


// CInPlaceFrame commands

void CInPlaceFrame::OnViewDesignbar()
{
	if (m_DesignBar.IsVisible())
		m_DesignBar.ShowWindow(SW_HIDE);
	else
		m_DesignBar.ShowWindow(SW_SHOW);
}

void CInPlaceFrame::OnUpdateViewDesignbar(CCmdUI *pCmdUI)
{
	pCmdUI->SetCheck(m_DesignBar.IsVisible());
}
