// MscGen2Doc.h : interface of the CMscGen2Doc class
//


#pragma once

#include "afxmt.h"
#include "libmscgen.h"
#include "afxwin.h"

class CMscGen2SrvrItem;

class CChartData {
public:
	char *m_buff;
	size_t m_length;
	BOOL m_bModified;
	CCriticalSection m_CriticalSection;
	CChartData() {m_buff=NULL; m_length=0; 	m_bModified = FALSE;}
	CChartData(const CChartData&);
	~CChartData() {if (m_buff) free(m_buff);}
	CChartData & operator = (const CChartData&);
	void Delete(void) {if (m_buff) free(m_buff); m_buff=NULL; m_length=0; m_bModified = FALSE;} //does not lock!

	BOOL Save(const CString &fileName);
	BOOL Load(const CString &fileName,  BOOL reportError=TRUE);
	void *CreateMsc(bool pedantic, const char *filename, const char *preamble=NULL, const char *postscript=NULL, const char*design=NULL);
	BOOL IsEmpty() const {return m_length==0 || m_buff==NULL;}
};

#pragma once


// COptionDlg dialog

class COptionDlg : public CDialog
{
	DECLARE_DYNCREATE(COptionDlg)

public:
	COptionDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~COptionDlg();
// Overrides

// Dialog Data
	enum { IDD = IDD_DIALOG_OPTIONS};

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()
public:
	BOOL m_Pedantic;
	BOOL m_Warnings;
	BOOL m_TextPaths;
	CString m_TextEditor;
	CString m_DefaultText;
	CString m_ViewMethod;
};

enum EStopEditor {STOPEDITOR_NOWAIT, STOPEDITOR_WAIT, STOPEDITOR_FORCE};

class CMscGen2Doc : public COleServerDoc
{
protected: // create from serialization only
	CMscGen2Doc();
	DECLARE_DYNCREATE(CMscGen2Doc)

// Attributes
public:
	CMscGen2SrvrItem* GetEmbeddedItem()
		{ return reinterpret_cast<CMscGen2SrvrItem*>(COleServerDoc::GetEmbeddedItem()); }

	//Actual Signalling Chart Data
	CChartData m_data;
	CChartData m_undo_data;
	BOOL m_undo_ModifiedFlag;
	//Options stored in registry
	BOOL m_Pedantic;
	BOOL m_Warnings;
	BOOL m_TextPaths;
	Msc_DrawType m_ViewMethod;
	CString m_sTextEditor;
	CString m_DefaultText;
	//Compilation options
	CString m_ChartSourcePreamble;
	CString m_ChartSourcePostscript;
	CString m_ForcedDesign;
	unsigned m_page;
	//Clipboard format
	static CLIPFORMAT m_cfPrivate;
	//The non-modal windows
	CDialog m_ErrorWindow;
	CDialog m_ProgressWindow;
	int m_progress_reference;
	//Text editor spawned process related
	DWORD m_EditorProcessId;
	CString m_EditorFileName;
	CTime m_EditorFileLastMod;
	HWND m_hWndForEditor;

// Operations
public:

// Overrides
	protected:
	virtual COleServerItem* OnGetEmbeddedItem();
	public:
	virtual void Serialize(CArchive& ar);

// Implementation
public:
	virtual ~CMscGen2Doc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()
	void OnSetItemRects(LPCRECT lpPosRect , LPCRECT lpClipRect);
public:
	// Destroys existing data, updates views
	virtual void DeleteContents();
	virtual BOOL OnNewDocument();
	virtual BOOL OnOpenDocument(LPCTSTR lpszPathName);
	virtual BOOL OnSaveDocument(LPCTSTR lpszPathName);
	virtual void OnCloseDocument();
	afx_msg void OnFileExport();
	afx_msg void OnEditCopy();
	afx_msg void OnEditPaste();
	afx_msg void OnEditPreferences();
public:
	void ReadRegistryValues(bool reportProblem);
	bool ReadDesigns(const char *fileName, bool reportProblem);
	void CopyErrorsToWindow(char *text);
	void StartEditor(CString = "");
	bool CheckIfEditorFileHasBeenUpdated(void);
	void StopEditor(EStopEditor force);
	void SetPagesInComboBox(unsigned pages);
	void StartDrawingProgress();
	void StopDrawingProgress();
protected:
	virtual void DestroyInPlaceFrame(COleIPFrameWnd* pFrameWnd);
	virtual COleIPFrameWnd* CreateInPlaceFrame(CWnd* pParentWnd);
	virtual void OnShowControlBars(CFrameWnd* pFrameWnd, BOOL bShow);
public:
	afx_msg void OnUpdateEditPaste(CCmdUI *pCmdUI);
	afx_msg void OnUpdateEditUndo(CCmdUI *pCmdUI);
	afx_msg void OnEditUndo();
	afx_msg void OnUpdateFileExport(CCmdUI *pCmdUI);
};


