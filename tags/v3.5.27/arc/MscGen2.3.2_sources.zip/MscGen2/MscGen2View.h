// MscGen2View.h : interface of the CMscGen2View class
//

#pragma once

#include "MscGen2Doc.h"

class CMscGen2View : public CScrollView
{
protected: // create from serialization only
	CMscGen2View();
	DECLARE_DYNCREATE(CMscGen2View)

// Attributes
public:
	// In percentage. 100 is normal
	int m_zoom;
	enum EZoomMode {NONE=0, OVERVIEW, WINDOW_WIDTH, ZOOM_WIDTH} m_ZoomMode;
	// EMF if view method is VIEW_EMF or WMF
	HENHMETAFILE m_hemf;
	HMETAFILE m_hwmf;
	bool m_DeleteBkg;
	// the chart if method is VIEW_DIRECT
	void *m_msc;
	unsigned m_xSize;
	unsigned m_ySize;
	unsigned m_pages;
#define MAX_ERROR_LENGTH 4096
	char m_errorText[MAX_ERROR_LENGTH];
	BOOL m_error;
	UINT_PTR m_hTimer;

// Implementation
public:
	virtual ~CMscGen2View();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

// Generated message map functions
protected:
	afx_msg void OnCancelEditSrvr();
	DECLARE_MESSAGE_MAP()
	virtual void OnUpdate(CView* /*pSender*/, LPARAM /*lHint*/, CObject* /*pHint*/);
public:
	CMscGen2Doc* GetDocument() const;
	void UpdateScrollSize(void);
	void ResyncScrollSize(void);
	void ArrangeWindowSize(EZoomMode);
	void SetZoomMode(EZoomMode mode);
	void StepDesignBar(int offset); //+1 or -1 steps, just updates after user selection change
	void StepPageBar(int offset); //+1 or -1 steps, just updates after user selection change
	void StartEditor(void); //Generate temp file name & start editor & timer
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void OnPrepareDC(CDC* pDC, CPrintInfo* pInfo = NULL);
	virtual void OnInitialUpdate();
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	afx_msg void OnButtonEdittext();
	afx_msg void OnUpdateButtonEdittext(CCmdUI *pCmdUI);
	afx_msg void OnButtonDesignLeft();
	afx_msg void OnButtonDesignRight();
	afx_msg void OnDesignComboSelChange();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnViewRedraw();
	afx_msg void OnBnClickedButtonPageMinus();
	afx_msg void OnBnClickedButtonPagePlus();
	afx_msg void OnCbnSelchangeComboPage();
	afx_msg void OnViewZoomnormalize();
	afx_msg void OnViewAdjustwidth();
	afx_msg void OnViewFittowidth();
	afx_msg void OnViewZoomin();
	afx_msg void OnViewZoomout();
	afx_msg void OnCbnSelchangeComboZoom();
	afx_msg void OnCbnEditchangeComboZoom();
	afx_msg void OnZoommodeKeepinoverview();
	afx_msg void OnZoommodeKeepadjustingwindowwidth();
	afx_msg void OnZoommodeKeepfittingtowidth();
	afx_msg void OnUpdateZoommodeKeepinoverview(CCmdUI *pCmdUI);
	afx_msg void OnUpdateZoommodeKeepadjustingwindowwidth(CCmdUI *pCmdUI);
	afx_msg void OnUpdateZoommodeKeepfittingtowidth(CCmdUI *pCmdUI);
	afx_msg void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
};

#ifndef _DEBUG  // debug version in MscGen2View.cpp
inline CMscGen2Doc* CMscGen2View::GetDocument() const
   { return reinterpret_cast<CMscGen2Doc*>(m_pDocument); }
#endif

