/*
    This file is part of Msc-generator.
	Copyright 2008,2009,2010 Zoltan Turanyi
	Distributed under GNU Affero General Public License.

    Msc-generator is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Msc-generator is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with Foobar.  If not, see <http://www.gnu.org/licenses/>.
*/
// MscGen2View.cpp : implementation of the CMscGen2View class
//

#include "stdafx.h"
#include "MscGen2.h"

#include "MscGen2Doc.h"
#include "MscGen2View.h"

#include <string>
#include <cmath>

#include "libmscgen.h"
#include ".\mscgen2view.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CMscGen2View

IMPLEMENT_DYNCREATE(CMscGen2View, CScrollView)

BEGIN_MESSAGE_MAP(CMscGen2View, CScrollView)
	ON_WM_MOUSEWHEEL()
	ON_WM_SIZE()
	ON_WM_TIMER()
	ON_WM_ERASEBKGND()
	ON_COMMAND(ID_CANCEL_EDIT_SRVR, OnCancelEditSrvr)
	ON_COMMAND(ID_BUTTON_EDITTEXT, OnButtonEdittext)
	ON_COMMAND(IDC_BUTTON_DESIGN_LEFT, OnButtonDesignLeft)
	ON_COMMAND(IDC_BUTTON_DESIGN_RIGHT, OnButtonDesignRight)
	ON_COMMAND(ID_VIEW_REDRAW, OnViewRedraw)
	ON_COMMAND(ID_VIEW_ZOOMNORMALIZE, OnViewZoomnormalize)
	ON_COMMAND(ID_VIEW_ADJUSTWIDTH, OnViewAdjustwidth)
	ON_COMMAND(ID_VIEW_FITTOWIDTH, OnViewFittowidth)
	ON_COMMAND(ID_VIEW_ZOOMIN, OnViewZoomin)
	ON_COMMAND(ID_VIEW_ZOOMOUT, OnViewZoomout)
	ON_COMMAND(ID_ZOOMMODE_KEEPINOVERVIEW, OnZoommodeKeepinoverview)
	ON_COMMAND(ID_ZOOMMODE_KEEPADJUSTINGWINDOWWIDTH, OnZoommodeKeepadjustingwindowwidth)
	ON_COMMAND(ID_ZOOMMODE_KEEPFITTINGTOWIDTH, OnZoommodeKeepfittingtowidth)
	ON_UPDATE_COMMAND_UI(ID_ZOOMMODE_KEEPINOVERVIEW, OnUpdateZoommodeKeepinoverview)
	ON_UPDATE_COMMAND_UI(ID_ZOOMMODE_KEEPADJUSTINGWINDOWWIDTH, OnUpdateZoommodeKeepadjustingwindowwidth)
	ON_UPDATE_COMMAND_UI(ID_ZOOMMODE_KEEPFITTINGTOWIDTH, OnUpdateZoommodeKeepfittingtowidth)
	ON_UPDATE_COMMAND_UI(ID_BUTTON_EDITTEXT, OnUpdateButtonEdittext)
	ON_BN_CLICKED(IDC_BUTTON_PAGE_MINUS, OnBnClickedButtonPageMinus)
	ON_BN_CLICKED(IDC_BUTTON_PAGE_PLUS, OnBnClickedButtonPagePlus)
	ON_CBN_SELCHANGE(IDC_COMBO_PAGE, OnCbnSelchangeComboPage)
	ON_CBN_SELCHANGE(IDC_COMBO_DESIGN, OnDesignComboSelChange)
	ON_CBN_SELCHANGE(IDC_COMBO_ZOOM, OnCbnSelchangeComboZoom)
	ON_CBN_EDITCHANGE(IDC_COMBO_ZOOM, OnCbnEditchangeComboZoom)
	ON_WM_KEYUP()
END_MESSAGE_MAP()

#define SCREEN_MARGIN 50 

// CMscGen2View construction/destruction

CMscGen2View::CMscGen2View()
{
	CMscGen2App *pApp = (CMscGen2App *)::AfxGetApp();
	// construction code here
	m_error = true;
	m_hemf = NULL;
	m_hwmf = NULL;
	m_msc = NULL;
	m_DeleteBkg = false;
	m_zoom = 100;
	m_ZoomMode = (EZoomMode)pApp->GetProfileInt(REG_SECTION_SETTINGS, REG_KEY_DEFAULTZOOMMODE, 0);
	m_xSize = 0;
	m_ySize = 0;
	m_pages = 0;
	m_hTimer = NULL;
	SetScrollSizes(MM_TEXT, CSize(0,0));
}

CMscGen2View::~CMscGen2View()
{
	if (m_hemf)
		DeleteEnhMetaFile(m_hemf);
	if (m_hwmf)
		DeleteMetaFile(m_hwmf);
	if (m_msc)
		Msc_Destroy(m_msc);
}

BOOL CMscGen2View::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs
	return CView::PreCreateWindow(cs);
}

// CMscGen2View drawing

BOOL CMscGen2View::OnEraseBkgnd(CDC *pDC)
{
	CMscGen2Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (m_DeleteBkg) {
		m_DeleteBkg = false;
		return TRUE;
	}
	if (pDoc->m_ViewMethod==DRAW_EMF) return FALSE;
	return CScrollView::OnEraseBkgnd(pDC);
}

void CMscGen2View::OnDraw(CDC* pDC)
{
	if (m_error) return;
	CRect r;
	CMscGen2Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (pDoc->IsInPlaceActive()) {
		pDoc->GetItemPosition(&r);
		r.bottom -= r.top; r.top = 0;
		r.right -= r.left; r.left = 0;
	} else 
		r.SetRect(0, 0, m_xSize*m_zoom/100.0, m_ySize*m_zoom/100.0);
	switch (pDoc->m_ViewMethod) {
	case DRAW_DIRECT:
		if (m_msc) 
			Msc_Draw(m_msc, pDC->m_hDC, DRAW_DIRECT, m_zoom, pDoc->m_TextPaths, pDoc->m_page);
		break;
	case DRAW_EMF:	
		if (m_hemf) {
			CRect clip;
			pDC->GetClipBox(&clip);
			CDC memDC;
			memDC.CreateCompatibleDC(pDC);
			CBitmap bitmap;
			bitmap.CreateCompatibleBitmap(pDC, clip.Width(), clip.Height());
			memDC.SelectObject(&bitmap);
			memDC.SetWindowOrg(clip.left, clip.top);
			memDC.FillSolidRect(clip, pDC->GetBkColor());
			PlayEnhMetaFile(memDC.m_hDC, m_hemf, r);
			pDC->BitBlt(clip.left, clip.top, clip.Width(),  clip.Height(),
				        &memDC, clip.left, clip.top, SRCCOPY);   
		}
		else if (m_hemf)
			PlayEnhMetaFile(pDC->m_hDC, m_hemf, r);
		break;
	case DRAW_WMF:
		if (m_hwmf) {
            CSize size(r.right, r.bottom);
			pDC->SetMapMode(MM_ANISOTROPIC);
			pDC->SetWindowExt(size);
			pDC->SetViewportExt(size);
			PlayMetaFile(pDC->m_hDC, m_hwmf);
		}
		break;
	}
}


// OLE Server support

// The following command handler provides the standard keyboard
//  user interface to cancel an in-place editing session.  Here,
//  the server (not the container) causes the deactivation
void CMscGen2View::OnCancelEditSrvr()
{
	GetDocument()->OnDeactivateUI(FALSE);
}


// CMscGen2View diagnostics

#ifdef _DEBUG
void CMscGen2View::AssertValid() const
{
	CScrollView::AssertValid();
}

void CMscGen2View::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}

CMscGen2Doc* CMscGen2View::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMscGen2Doc)));
	return (CMscGen2Doc*)m_pDocument;
}
#endif //_DEBUG


// CMscGen2View message handlers

BOOL CMscGen2View::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt)
{
	if (GetDocument()->IsInPlaceActive()) 
		return CScrollView::OnMouseWheel(nFlags, zDelta, pt);
	if (!(nFlags & MK_CONTROL))
		return CScrollView::OnMouseWheel(nFlags, zDelta, pt);
	unsigned zoom = m_zoom*(1+float(zDelta)/WHEEL_DELTA/10);  //10% per wheel tick
	if (zoom < 10) zoom = 10;
	if (zoom > 10000) zoom = 10000;
	if (zoom == m_zoom) 
		return CScrollView::OnMouseWheel(nFlags, zDelta, pt);
	RECT view;
	GetClientRect(&view);
	ScreenToClient(&pt);
	CPoint pos = GetDeviceScrollPosition() + pt;
	pos.x = double(pos.x)/m_zoom * zoom;
	pos.y = double(pos.y)/m_zoom * zoom;
	pos -= pt;
	if (pos.x < 0) pos.x = 0;
	if (pos.y < 0) pos.y = 0;
	m_zoom = zoom;
	ScrollToDevicePosition(pos);
	UpdateScrollSize();
	return CScrollView::OnMouseWheel(nFlags, zDelta, pt);
}

void CMscGen2View::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint)
{
	CMscGen2Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->StartDrawingProgress();

	if (m_hemf) {
		DeleteEnhMetaFile(m_hemf);
		m_hemf = NULL;
	}
	if (m_hwmf) {
		DeleteMetaFile(m_hwmf);
		m_hwmf = NULL;
	}
	if (m_msc) {
		Msc_Destroy(m_msc);
		m_msc = NULL;
	}
	//Save old size
	CSize sizeOld(m_xSize, m_ySize);

	//See if we have the (potentially) new ForcedDesign verified & copied to the combo box of DesignBar
	CMscGen2App *pApp = (CMscGen2App *)::AfxGetApp();
	if (pApp != NULL) {
		//Store the design (we may have loaded for embedded objects via serialize) 
		//Needed as inplace frame will create control bar only after calling this function
		pApp->m_ForcedDesignToShow = pDoc->m_ForcedDesign;
		//We also update the bar now, as for non-in place embedded editing the control is already done.
		if (pApp->m_pDesignBar != NULL) {
			CComboBox *combo = (CComboBox*)pApp->m_pDesignBar->GetDlgItem(IDC_COMBO_DESIGN);
			if (combo!=NULL) {
				//Set the index to the current forced design
				int index = combo->FindString(-1, pDoc->m_ForcedDesign);
				if (index<0) index = 0;
				combo->SetCurSel(index);
				//Adjust m_ForcedDesign (FindString searches for prefixes)
				if (index == 0)
					pDoc->m_ForcedDesign.Empty();
				else
					combo->GetLBText(index, pDoc->m_ForcedDesign);
			}
		}
	}
	//Ok, now compile the data read
	//if no chart, then we do not parse the postscript or preamble to get an empty chart
	void* msc;
	if (pDoc->m_data.IsEmpty())
		msc = pDoc->m_data.CreateMsc(pDoc->m_Pedantic, "", "", "", "");
	else
		msc = pDoc->m_data.CreateMsc(pDoc->m_Pedantic, "", pDoc->m_ChartSourcePreamble, 
                                     pDoc->m_ChartSourcePostscript, pDoc->m_ForcedDesign);

	if (m_xSize > Msc_GetXSize(msc, pDoc->m_page) ||
		m_ySize > Msc_GetYSize(msc, pDoc->m_page))
		m_DeleteBkg = true;
	m_xSize = Msc_GetXSize(msc, pDoc->m_page);
	m_ySize = Msc_GetYSize(msc, pDoc->m_page);
	m_error = Msc_GetErrors(msc, pDoc->m_Warnings, m_errorText, MAX_ERROR_LENGTH);
	m_pages = Msc_GetPages(msc);
	pDoc->SetPagesInComboBox(m_pages);
	HDC hdc;
	if (!m_error) {
		switch (pDoc->m_ViewMethod) {
		case DRAW_DIRECT:
			m_msc = msc;
			break;
		case DRAW_EMF:
            hdc = CreateEnhMetaFile(NULL, NULL, NULL, NULL);
			Msc_Draw(msc, hdc, DRAW_EMF, 100, pDoc->m_TextPaths, pDoc->m_page);
			m_hemf = CloseEnhMetaFile(hdc);
			Msc_Destroy(msc);
			break;
		case DRAW_WMF:
            hdc = CreateMetaFile(NULL);
			Msc_Draw(msc, hdc, DRAW_WMF, 100, pDoc->m_TextPaths, pDoc->m_page);
			m_hwmf = CloseMetaFile(hdc);
			Msc_Destroy(msc);
			break;
		}
	}
	//Copy errors/warnings to the error window & show/hide as appropriate
	pDoc->CopyErrorsToWindow(m_errorText);
	//Recalculate the size if in-place editing
	if (pDoc->IsInPlaceActive() && m_xSize>0 && m_ySize>0) {
		CSize sizeNew(m_xSize, m_ySize);
		CClientDC dc(this);
		dc.LPtoDP(&sizeNew);
		dc.LPtoDP(&sizeOld);
		RECT origPos;
		pDoc->GetItemPosition(&origPos);
		//Calculate the new size to remain proportional to the old magnification - but correct aspect ratio
		double origClientArea = double(origPos.bottom - origPos.top) * double(origPos.right - origPos.left);
		double origChartArea = double(sizeOld.cx) * double(sizeOld.cy);
		double scale = sqrt(origClientArea / origChartArea); //Existing scale from Chart area to Client Area
		int newClient_x = int(scale*sizeNew.cx);
		int newClient_y = int(scale*sizeNew.cy);
		CRect newPos(origPos.left, origPos.top, origPos.left + newClient_x, origPos.top + newClient_y);
		pDoc->RequestPositionChange(newPos);
		ResizeParentToFit(FALSE);
	} 
	ArrangeWindowSize(m_ZoomMode);
	UpdateScrollSize();
	pDoc->StopDrawingProgress();
}

void CMscGen2View::UpdateScrollSize(void)
{
	ResyncScrollSize();
	CMscGen2App *pApp = (CMscGen2App *)::AfxGetApp();
	CComboBox *combo = (CComboBox*)pApp->m_pDesignBar->GetDlgItem(IDC_COMBO_ZOOM);
	CString text;
	text.Format("%u%%", m_zoom);
	combo->SetWindowText(text);
	CScrollView::Invalidate();
}

void CMscGen2View::OnPrepareDC(CDC* pDC, CPrintInfo* pInfo)
{
	CMscGen2Doc* pDoc = GetDocument();
	CScrollView::OnPrepareDC(pDC, pInfo);

	pDC->SetMapMode(MM_ANISOTROPIC);
	CSize sizeDoc(m_xSize*m_zoom/100.0?m_xSize:10, m_ySize*m_zoom/100.0?m_ySize:10);
	pDC->SetWindowExt(sizeDoc);

	CSize sizeNum, sizeDenom;
	pDoc->GetZoomFactor(&sizeNum, &sizeDenom);

	int xLogPixPerInch = pDC->GetDeviceCaps(LOGPIXELSX);
	int yLogPixPerInch = pDC->GetDeviceCaps(LOGPIXELSY);

	long xExt = (long)sizeDoc.cx * xLogPixPerInch * sizeNum.cx;
	xExt /= 100 * (long)sizeDenom.cx;
	long yExt = (long)sizeDoc.cy * yLogPixPerInch * sizeNum.cy;
	yExt /= 100 * (long)sizeDenom.cy;
	pDC->SetViewportExt((int)xExt, (int)yExt);
}


void CMscGen2View::ResyncScrollSize(void)
{
	if (m_xSize==0 || m_ySize==0) return;
	CSize sizeDoc(m_xSize*m_zoom/100, m_ySize*m_zoom/100);
	SetScrollSizes(MM_TEXT, sizeDoc);
}

void CMscGen2View::ArrangeWindowSize(EZoomMode mode)
{
	if (m_xSize==0 || m_ySize==0 || mode == NONE) 
		return;
	CMscGen2Doc *pDoc = GetDocument();
	ASSERT(pDoc);
	if (pDoc->IsEmbedded())
		return;
	RECT view, window, screen;
	GetClientRect(&view);
	CWnd *parent = 	GetParent();
	parent->GetWindowRect(&window); 
	CClientDC dc(NULL);
	dc.GetClipBox(&screen);
	//calculate the space available to a view on the screen
	unsigned x, y;
	x = screen.right-screen.left;
	x -= (window.right-window.left) - (view.right-view.left) + SCREEN_MARGIN;
	y = screen.bottom-screen.top;
	y -= (window.bottom-window.top) - (view.bottom-view.top) + SCREEN_MARGIN;
	switch (mode) {
		case OVERVIEW:
			//See which dimension is limiting
			if (double(y)/double(x) > double(m_ySize)/double(m_xSize)) 
				m_zoom = double(x)/double(m_xSize)*100.;
			else 
				m_zoom = double(y)/double(m_ySize)*100.;
			if (m_zoom > 100) m_zoom = 100;
			x = m_zoom*m_xSize/100 + 1;
			y = m_zoom*m_ySize/100 + 1;
			//now result is the client size
			x += (window.right-window.left) - (view.right-view.left);
			y += (window.bottom-window.top) - (view.bottom-view.top);
			//now result is the window size, now adjust for minimum size
			if (x < 550) x = 580;
			if (y < 300) y = 300;
			if (window.left + x > screen.right - SCREEN_MARGIN)
				window.left = screen.right - SCREEN_MARGIN - x;
			if (window.top + y > screen.bottom - SCREEN_MARGIN)
				window.top = screen.bottom - SCREEN_MARGIN - y;
			parent->SetWindowPos(NULL, window.left, window.top, x, y,  SWP_NOZORDER | SWP_NOACTIVATE);
			break;
		case WINDOW_WIDTH:
			//Try fit real size
			m_zoom = 100;
			//if window is big enough do nothing
			if (view.right-view.left > m_zoom*m_xSize/100 + 1) break;
			//adjust zoom if there is not enough space
			if (m_zoom*m_xSize/100 + 1 > x)
				m_zoom = (x-1)*100./m_xSize;
			x = m_zoom*m_xSize/100 + 1;
			if (x < 550) x = 580;
			if (window.left + x > screen.right - SCREEN_MARGIN)
				window.left = screen.right - SCREEN_MARGIN - x;
			parent->SetWindowPos(NULL, window.left, window.top, x, (window.bottom-window.top),  SWP_NOZORDER | SWP_NOACTIVATE);
			break;
		case ZOOM_WIDTH:
			m_zoom = (view.right-view.left)*100./m_xSize;
			if (m_zoom>500) m_zoom = 500;
			break;
	}

}

void CMscGen2View::OnInitialUpdate()
{
	CScrollView::OnInitialUpdate();
	CMscGen2Doc *pDoc = GetDocument();
	ASSERT(pDoc);
	if (pDoc->IsEmbedded())
		StartEditor(); //Start the text editor only for embedded doc
	else 
		ArrangeWindowSize(OVERVIEW);
}

void CMscGen2View::OnSize(UINT nType, int cx, int cy)
{
	//CScrollView::OnSize(nType, cx, cy);
	ResyncScrollSize(); 
}

void CMscGen2View::OnViewZoomnormalize()
{
	ArrangeWindowSize(OVERVIEW);
	UpdateScrollSize();
}

void CMscGen2View::OnViewAdjustwidth()
{
	ArrangeWindowSize(WINDOW_WIDTH);
	UpdateScrollSize();
}

void CMscGen2View::OnViewFittowidth()
{
	ArrangeWindowSize(ZOOM_WIDTH);
	UpdateScrollSize();
}

void CMscGen2View::OnViewZoomin()
{
	unsigned zoom = m_zoom*1.1;
	if (zoom > 10000) zoom = 10000;
	if (zoom != m_zoom) {
		m_zoom = zoom;
		UpdateScrollSize();
	}
}

void CMscGen2View::OnViewZoomout()
{
	unsigned zoom = m_zoom*0.9;
	if (zoom < 10) zoom = 10;
	if (zoom != m_zoom) {
		m_zoom = zoom;
		UpdateScrollSize();
	}
}

void CMscGen2View::OnCbnSelchangeComboZoom()
{
	static unsigned zoom_values[] = {0, 400, 300, 200, 150, 100, 75, 50, 40, 30, 20, 10};
	CMscGen2App *pApp = (CMscGen2App *)::AfxGetApp();
	CComboBox *combo = (CComboBox*)pApp->m_pDesignBar->GetDlgItem(IDC_COMBO_ZOOM);
	unsigned index = combo->GetCurSel();
	if (index==0) {
		OnViewZoomnormalize();
	} else {
		m_zoom = zoom_values[index];
		UpdateScrollSize();
	}
}

void CMscGen2View::OnCbnEditchangeComboZoom()
{
	CMscGen2App *pApp = (CMscGen2App *)::AfxGetApp();
	CComboBox *combo = (CComboBox*)pApp->m_pDesignBar->GetDlgItem(IDC_COMBO_ZOOM);
	CString text;
	combo->GetWindowText(text);
	int a = atoi(text);
	if (a>10 && a<10000) {
		m_zoom = a;
		UpdateScrollSize();
	}
}

void CMscGen2View::StartEditor(void) 
{
	CMscGen2Doc *pDoc = GetDocument();
	ASSERT(pDoc);
	CString title;
	if (pDoc->IsEmbedded()) {
		title = "Embedded Chart";
	} else {
		CWnd *parent = GetParent();
		while (parent) {
			parent->GetWindowText(title);
			parent = parent->GetParent();
		}
		if (title.Right(16) == " - Msc-generator")
			title = title.Left(title.GetLength()-16);
		else if (title.Right(13) == "Msc-generator")
			title = title.Left(title.GetLength()-13);
	}
	pDoc->StartEditor(title);
	m_hTimer = SetTimer(1, 100, NULL);
}

void CMscGen2View::OnButtonEdittext()
{
	CMscGen2Doc *pDoc = GetDocument();
	ASSERT(pDoc);
	if (pDoc->m_EditorProcessId)
		pDoc->StopEditor(STOPEDITOR_NOWAIT);
	else
		this->StartEditor();
}

void CMscGen2View::OnUpdateButtonEdittext(CCmdUI *pCmdUI)
{
	CMscGen2Doc *pDoc = GetDocument();
	ASSERT(pDoc);
	pCmdUI->SetCheck(pDoc->m_EditorProcessId != 0);
}

void CMscGen2View::OnButtonDesignLeft()
{
	StepDesignBar(-1);
}
void CMscGen2View::OnButtonDesignRight()
{
	StepDesignBar(+1);
}

void CMscGen2View::OnDesignComboSelChange() 
{
	StepDesignBar(0);
}

void CMscGen2View::StepDesignBar(int offset)
{
	CMscGen2App *pApp = (CMscGen2App *)::AfxGetApp();
	if (pApp == NULL) return;
	if (pApp->m_pDesignBar == NULL) return;
	CComboBox *combo = (CComboBox*)pApp->m_pDesignBar->GetDlgItem(IDC_COMBO_DESIGN);
	if (combo==NULL) return;
	if (combo->GetCount()<2) return;
	int index = combo->GetCurSel();
	switch (offset){
		case -1:
		case +1:
			index = (index + combo->GetCount() + offset) % combo->GetCount();
			break;
		default:
			break;
	}
	combo->SetCurSel(index);
	CMscGen2Doc *pDoc = GetDocument();
	if (pDoc == NULL) return;
	CString old_forcedDesign(pDoc->m_ForcedDesign);
	if (index == 0)
		pDoc->m_ForcedDesign.Empty();
	else
		combo->GetLBText(index, pDoc->m_ForcedDesign);
	//We save forceddesign only in an embedded doc, so changing that counts as modified
	if (pDoc->IsEmbedded() && pDoc->m_ForcedDesign != old_forcedDesign)
		pDoc->SetModifiedFlag(); 
	pDoc->NotifyChanged();  //for OLE
	pDoc->UpdateAllViews(NULL);
}


void CMscGen2View::OnTimer(UINT nIDEvent)
{
	CMscGen2Doc *pDoc = GetDocument();
	ASSERT(pDoc);

	//_First_ check for a modified file (if editor saved file & closed)

	pDoc->CheckIfEditorFileHasBeenUpdated();
	//Do nothing if file was removed or juts not modified 
	//or modified, but impossuble to load

	//Check if the Editor is still running
	if (pDoc->m_EditorProcessId == 0) {
		KillTimer(m_hTimer);
		m_hTimer = NULL;
	} else {
		HANDLE h = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, pDoc->m_EditorProcessId);
		if (!GetPriorityClass(h)) { //this checks if process still there
			KillTimer(m_hTimer);
			m_hTimer = NULL;
			pDoc->m_EditorProcessId = 0;
			pDoc->StopEditor(STOPEDITOR_FORCE); //remove editor file & zero out 
		}
		CloseHandle(h);
	}
}

void CMscGen2View::OnViewRedraw()
{
	CMscGen2Doc *pDoc = GetDocument();
	ASSERT(pDoc);
	pDoc->UpdateAllViews(NULL);
}

void CMscGen2View::OnBnClickedButtonPageMinus()
{
	StepPageBar(-1);
}

void CMscGen2View::OnBnClickedButtonPagePlus()
{
	StepPageBar(+1);
}

void CMscGen2View::OnCbnSelchangeComboPage()
{
	StepPageBar(0);
}

void CMscGen2View::StepPageBar(int offset)
{
	CMscGen2App *pApp = (CMscGen2App *)::AfxGetApp();
	if (pApp == NULL) return;
	if (pApp->m_pDesignBar == NULL) return;
	CComboBox *combo = (CComboBox*)pApp->m_pDesignBar->GetDlgItem(IDC_COMBO_PAGE);
	if (combo==NULL) return;
	if (combo->GetCount()<2) return;
	int index = combo->GetCurSel();
	switch (offset){
		case -1:
		case +1:
			index = (index + combo->GetCount() + offset) % combo->GetCount();
			break;
		default:
			break;
	}
	combo->SetCurSel(index);
	CMscGen2Doc *pDoc = GetDocument();
	if (pDoc == NULL) return;
	unsigned oldPage = pDoc->m_page;
	pDoc->m_page = index;

	//We save forceddesign only in an embedded doc, so changing that counts as modified
	if (pDoc->IsEmbedded() && pDoc->m_page!= oldPage)
		pDoc->SetModifiedFlag(); 
	pDoc->NotifyChanged();  //for OLE
	pDoc->UpdateAllViews(NULL);
}

void CMscGen2View::SetZoomMode(EZoomMode mode)
{
	if (m_ZoomMode == mode) 
		m_ZoomMode = NONE;
	else
		m_ZoomMode = mode;
	ArrangeWindowSize(m_ZoomMode);
	UpdateScrollSize();
	CMscGen2App *pApp = (CMscGen2App *)::AfxGetApp();
	pApp->WriteProfileInt(REG_SECTION_SETTINGS, REG_KEY_DEFAULTZOOMMODE, m_ZoomMode);
}

void CMscGen2View::OnZoommodeKeepinoverview()
{
	SetZoomMode(OVERVIEW);
}

void CMscGen2View::OnZoommodeKeepadjustingwindowwidth()
{
	SetZoomMode(WINDOW_WIDTH);
}

void CMscGen2View::OnZoommodeKeepfittingtowidth()
{
	SetZoomMode(ZOOM_WIDTH);
}

void CMscGen2View::OnUpdateZoommodeKeepinoverview(CCmdUI *pCmdUI)
{
	CMscGen2Doc *pDoc = GetDocument();
	ASSERT(pDoc);
	pCmdUI->SetCheck(m_ZoomMode == OVERVIEW);
}

void CMscGen2View::OnUpdateZoommodeKeepadjustingwindowwidth(CCmdUI *pCmdUI)
{
	CMscGen2Doc *pDoc = GetDocument();
	ASSERT(pDoc);
	pCmdUI->SetCheck(m_ZoomMode == WINDOW_WIDTH);
}

void CMscGen2View::OnUpdateZoommodeKeepfittingtowidth(CCmdUI *pCmdUI)
{
	CMscGen2Doc *pDoc = GetDocument();
	ASSERT(pDoc);
	pCmdUI->SetCheck(m_ZoomMode == ZOOM_WIDTH);
}

void CMscGen2View::OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	switch (nChar) {
		case VK_HOME:  OnScroll(SB_TOP*256       + SB_ENDSCROLL, 0); break;
		case VK_END:   OnScroll(SB_BOTTOM*256    + SB_ENDSCROLL, 0); break;
		case VK_PRIOR: OnScroll(SB_PAGEUP*256    + SB_ENDSCROLL, 0); break;
		case VK_NEXT:  OnScroll(SB_PAGEDOWN*256  + SB_ENDSCROLL, 0); break;
		case VK_UP:    OnScroll(SB_LINEUP*256    + SB_ENDSCROLL, 0); break;
		case VK_DOWN:  OnScroll(SB_LINEDOWN*256  + SB_ENDSCROLL, 0); break;
		case VK_LEFT:  OnScroll(SB_ENDSCROLL*256 + SB_LINELEFT,  0); break;
		case VK_RIGHT: OnScroll(SB_ENDSCROLL*256 + SB_LINERIGHT, 0); break;
		default: CScrollView::OnKeyUp(nChar, nRepCnt, nFlags);
	}
}
