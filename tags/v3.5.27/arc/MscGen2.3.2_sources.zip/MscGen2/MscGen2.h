// MscGen2.h : main header file for the MscGen2 application
//
#pragma once

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

// CMscGen2App:
// See MscGen2.cpp for the implementation of this class
//

class CMscGen2App : public CWinApp
{
public:
	CMscGen2App();
	CString m_ForcedDesignToShow;
	CDialogBar *m_pDesignBar;

// Overrides
public:
	virtual BOOL InitInstance();

// Implementation
	COleTemplateServer m_server;  // Server object for document creation
	afx_msg void OnAppAbout();
	bool CommandLineMain(CString cmd);
	void FillComboWithDesigns(const char *preamble);
	DECLARE_MESSAGE_MAP()
};

extern CMscGen2App theApp;

//Registry data keys
#define REG_SECTION_SETTINGS "Settings"
#define REG_KEY_PEDANTIC "Pedantic"
#define REG_KEY_WARNINGS "Warnings"
#define REG_KEY_TEXTEDITOR "TextEditor"
#define REG_KEY_DEFAULTTEXT "DefaultText"
#define REG_KEY_DEFAULTZOOMMODE "DefaultZoomMode"
//#define REG_KEY_TEXTPATHS "UseTextPaths"
//#define REG_KEY_VIEWMETHOD "ViewMethod"
//#define REG_KEY_DESIGNLIBFILE "DesignLibFile"


