// SrvrItem.h : interface of the CMscGen2SrvrItem class
//

#pragma once

class CMscGen2SrvrItem : public COleServerItem
{
	DECLARE_DYNAMIC(CMscGen2SrvrItem)

// Constructors
public:
	CMscGen2SrvrItem(CMscGen2Doc* pContainerDoc);

// Attributes
	CMscGen2Doc* GetDocument() const
		{ return reinterpret_cast<CMscGen2Doc*>(COleServerItem::GetDocument()); }

// Overrides
	public:
	virtual BOOL OnDraw(CDC* pDC, CSize& rSize);
	virtual BOOL OnGetExtent(DVASPECT dwDrawAspect, CSize& rSize);

// Implementation
public:
	~CMscGen2SrvrItem();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	virtual void Serialize(CArchive& ar);   // overridden for document i/o
public:
	virtual BOOL OnRenderData(LPFORMATETC lpFormatEtc, LPSTGMEDIUM lpStgMedium);
	BOOL GetTextData(LPFORMATETC lpFormatEtc , LPSTGMEDIUM lpStgMedium);
	BOOL GetBitmapData(LPFORMATETC lpFormatEtc , LPSTGMEDIUM lpStgMedium);
	virtual COleDataSource* OnGetClipboardData(BOOL bIncludeLink, LPPOINT lpOffset, LPSIZE lpSize);
	DECLARE_MESSAGE_MAP()
};

