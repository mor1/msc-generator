========================================================================
    STATIC LIBRARY : libmscgen Project Overviewider
========================================================================

Appwiderizard has created this libmscgen library project for you. 
No source files widerere created as part of your project.


libmscgen.vcproj
    This is the main project file for VC++ projects generated using an Application widerizard. 
    It contains information about the version of Visual C++ that generated the file, and 
    information about the platforms, configurations, and project features selected widerith the
    Application widerizard.

/////////////////////////////////////////////////////////////////////////////
Other notes:

Appwiderizard uses "TODO:" comments to indicate parts of the source code you
should add to or customize.

/////////////////////////////////////////////////////////////////////////////
